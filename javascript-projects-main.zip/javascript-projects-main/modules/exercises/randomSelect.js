function randomFromArray(arr){
  //Your code here to select a random element from the array passed to the function.
}

//TODO: Export the randomFromArray function.
