function callMe(func) {
    func();
}

callMe("Al");
