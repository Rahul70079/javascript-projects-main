function printMessage() {
    console.log("The future is now!");
}

setTimeout(printMessage, 5000);
