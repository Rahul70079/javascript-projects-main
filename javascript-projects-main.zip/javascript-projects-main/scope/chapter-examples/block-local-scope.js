function myFunction() {
    let i = 10;
    return 10 + i;
}

console.log(i);
