const input = require('readline-sync');

let num1 = input.question("Enter a number: ");
let num2 = input.question("Enter another number: ");

console.log(num1 + num2);
