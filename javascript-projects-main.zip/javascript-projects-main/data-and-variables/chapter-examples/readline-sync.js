const input = require('readline-sync');

let info = input.question("Question text... ");
