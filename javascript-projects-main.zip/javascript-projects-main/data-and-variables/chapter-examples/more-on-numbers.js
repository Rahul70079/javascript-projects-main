console.log(42000);
console.log(42,000);

console.log(42, 17, 56, 34, 11, 4.35, 32);
console.log(3.4, "hello", 45);
