console.log(typeof "Hello, World!");
console.log(typeof 17);
console.log(typeof 3.14);
