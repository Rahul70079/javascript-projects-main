console.log('Bruce's beard');
