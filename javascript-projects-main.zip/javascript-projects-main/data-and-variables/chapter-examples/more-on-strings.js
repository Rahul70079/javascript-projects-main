console.log(typeof "17");
console.log(typeof "3.2");

console.log(typeof 'This is a string');
console.log(typeof "And so is this");
