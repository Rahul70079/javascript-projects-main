const input = require('readline-sync');

let name = input.question("Enter your name: ");
