console.log(Number("2345"));
console.log(typeof Number("2345"));
console.log(Number(17));

console.log(Number("23bottles"));

console.log(String(17));
console.log(String(123.45));
console.log(typeof String(123.45));
