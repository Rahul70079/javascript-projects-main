describe("transmission processor", function() {

   //  TODO: put tests here
 
 });