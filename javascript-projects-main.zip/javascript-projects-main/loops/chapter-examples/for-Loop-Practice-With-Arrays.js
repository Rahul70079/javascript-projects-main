// create an array variable containing the names

// write a for loop that prints each name on a different line
