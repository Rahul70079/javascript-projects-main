// Experiment with this loop by modifying each of the following: the variable initialization, the boolean condition, and the update expression.

for (let i = 0; i < 51; i++) {
   console.log(i);
 }