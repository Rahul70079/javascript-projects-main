// Create a string variable containing your name.


// Write a for loop that prints each character in your name on a different line.