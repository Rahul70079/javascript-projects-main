let i = 0;

while (i < 51) {
  console.log(i);
  i++;
}