const shuttleManagement = require('./solution.js');

shuttleManagement.runProgram();