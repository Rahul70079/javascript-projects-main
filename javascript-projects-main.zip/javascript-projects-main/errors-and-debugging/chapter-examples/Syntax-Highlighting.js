let name = Julie;
console.log("Hello, name);