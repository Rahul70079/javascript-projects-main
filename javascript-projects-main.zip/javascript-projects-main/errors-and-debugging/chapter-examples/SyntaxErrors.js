let day = Wednesday;
console.log(day;