// You do not need to do anything with script.js right now! Later, we will learn how to add JavaScript to websites!
