   // This demo shows off comments!

   // console.log("This does not print.");

   console.log("Hello, World!"); // Comments do not have to start at the beginning of a line.

   /* Here is how
   to have
   multi-line
   comments. */

   console.log("Comments make your code more readable by others.");
