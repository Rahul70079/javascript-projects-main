console.log('Hello, JavaScript.');
console.log(2001);
console.log("What","do","commas","do?");
console.log("Does", "adding",      "space", "matter?");
console.log('Launch' + 'Code');
console.log("LaunchCode was founded in", 2013);
