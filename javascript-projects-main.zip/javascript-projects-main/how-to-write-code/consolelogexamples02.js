console.log("Some Programming Languages:");

console.log("Python\nJavaScript\nJava\nC#\nSwift");
