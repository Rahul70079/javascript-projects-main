const studio = require('./array-testing');

console.log(studio.reverseCommas());
console.log(studio.semiDash());
console.log(studio.reverseSpaces());
console.log(studio.commaSpace());

//NOTE: open the array-testing.js file to begin coding
